/*
 * @Author: daihanqiao@126.com
 * @Date: 2021-04-09 16:45:04
 * @LastEditTime: 2021-04-15 16:13:24
 * @LastEditors: daihanqiao@126.com
 */
import Utils from './index'
export default {
  formatStr: Utils.formatStr,
  formatTime: Utils.formatTime,
  formatDate: Utils.formatDate,
  encryPhone: Utils.encryPhone
}
