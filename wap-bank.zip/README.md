# wap-bank

> 运行前，先检查是否安装了( yarn包管理)， 没安装的话先 `npm i yarn -g`
## 安装依赖
```
yarn
```

### 运行项目
```
yarn start
```

### 项目打包
```
yarn build
```

### 资源
设计搞： [ui图](https://codesign.qq.com/s/2bzpZvJ4qXZkAaV).


